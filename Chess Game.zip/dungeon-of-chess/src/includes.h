#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <memory>
#include <map>
#include <thread>
