# chess game with cpp

Hello this is a chess game made in SDL2 and GL3, with fews of features (cursed immediate tessellator).
The game contains a primitve workable IA to play.

The IA is primitve but is smart at some point.

# build

To build is easy, just import the build file in sublime_text_build.
I coded this in sublime text so I made this build file.
The program uses MinGW64, anyway this is not a serious project.

# running



# splash

![Alt text](/splash/splash_gameplay_1.png?raw=true)
![Alt text](/splash/splash_gameplay_2.png?raw=true)
